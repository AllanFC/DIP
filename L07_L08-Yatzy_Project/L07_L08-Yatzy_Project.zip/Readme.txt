Allan

Hvis der skulle være en mangel ville det være at man ikke kan vælge et andet resultat efter man har låst et andet. Dette var dog bare fordi jeg ikke syntes det var nødvendigt.